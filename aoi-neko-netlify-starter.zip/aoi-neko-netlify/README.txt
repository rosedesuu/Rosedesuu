# Aoi Neko — Netlify starter website

This is a static starter website for Aoi Neko, styled in a minimal pastel-blue / cute-premium direction.

## Files
- `index.html` — page content and sections
- `style.css` — colors, layout, responsive styling
- `script.js` — price tabs, mobile menu, sample order form, sample tracker

## Before publishing
1. Open `script.js` and replace `YOUR-EMAIL@example.com` with the email address that should receive order requests.
2. In `script.js`, edit the `prices` object with your actual Genshin Impact and Wuthering Waves services, prices, and descriptions.
3. In `index.html`, replace the payment method text with your confirmed payment methods and add payment instructions only when ready.
4. Review and replace the starter Terms & Conditions with your complete final policies.
5. Add your official social links and contact details where you want them displayed.
6. Test the page on desktop and mobile.

## Publish on Netlify (quick method)
1. Extract the ZIP file.
2. Go to https://app.netlify.com/drop and sign in.
3. Drag the extracted `aoi-neko-netlify` folder onto the drop area.
4. Netlify will publish it and provide a `*.netlify.app` address.
5. In Netlify site settings, you can change the site name if the name you want is available.

## Important limitations
- The order form currently uses a `mailto:` link. It opens the visitor's email app; it does not store submissions on a server. For a proper online form, connect Netlify Forms or a form provider.
- The progress tracker is a visual demo only. It contains one sample order (`AN-0001`, access code `AOI2026`) and does not protect or retrieve real client records. Do not put real client data in this static site. A secure tracker needs authenticated server-side storage or a private per-client report link with suitable access controls.
- This site does not process payments. It only displays payment information.
- Google Fonts requires an internet connection; fallback fonts are included.
