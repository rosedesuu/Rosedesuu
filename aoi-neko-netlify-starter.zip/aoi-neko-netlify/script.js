const prices = {
  genshin: [
    ["Exploration","Area completion based on agreed objectives.","₱ — / area"],
    ["Quest completion","Selected quests and story-related objectives.","₱ — / request"],
    ["Other services","Discuss your requested task and scope first.","Ask for a quote"]
  ],
  wuwa: [
    ["Exploration","Area completion based on agreed objectives.","₱ — / area"],
    ["Quest completion","Selected quests and story-related objectives.","₱ — / request"],
    ["Other services","Discuss your requested task and scope first.","Ask for a quote"]
  ]
};
const grid=document.getElementById("priceGrid");
function renderPrices(game){grid.innerHTML=prices[game].map(([name,desc,price])=>`<article class="price-card"><span class="tag">${game==="genshin"?"FOR TRAVELERS":"FOR ROVERS"}</span><h3>${name}</h3><p>${desc}</p><div class="price">${price}</div></article>`).join("");}
renderPrices("genshin");
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderPrices(btn.dataset.game);}));
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();

document.getElementById("orderForm").addEventListener("submit",e=>{
  e.preventDefault();
  const data=Object.fromEntries(new FormData(e.target).entries());
  const subject=encodeURIComponent("Aoi Neko Order Request - "+data.game);
  const body=encodeURIComponent(`Name: ${data.client}\nContact: ${data.contact}\nGame: ${data.game}\nService: ${data.service}\nServer: ${data.server||"Not specified"}\nObjectives: ${data.details||"Not specified"}\nPreferred schedule: ${data.schedule||"Flexible"}\n\nPlease confirm availability and final quotation.`);
  document.getElementById("formStatus").textContent="Your email app should open with your order details. Add your business email in script.js first.";
  window.location.href=`mailto:YOUR-EMAIL@example.com?subject=${subject}&body=${body}`;
});

document.getElementById("trackButton").addEventListener("click",()=>{
  const ref=document.getElementById("orderRef").value.trim().toUpperCase();
  const code=document.getElementById("accessCode").value.trim();
  const result=document.getElementById("trackerResult");
  if(ref==="AN-0001" && code==="AOI2026"){
    result.innerHTML="<b>Sample order · In progress</b><br>Service: Exploration<br>Latest update: Work has started. This is sample content only.<br><small>Replace this demo with a secure, private client tracker before using real orders.</small>";
  }else{
    result.textContent="No demo record found. Try order reference AN-0001 and access code AOI2026. This demo does not look up real client orders.";
  }
});
